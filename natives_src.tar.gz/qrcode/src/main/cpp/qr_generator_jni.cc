#include <jni.h>
#include <cstdint>
#include <cstdlib>
#include <cstring>
#include <iostream>
#include <string>
#include <vector>
#include "qr_code.hpp"

using std::uint8_t;

extern "C" JNIEXPORT jstring Java_com_umerov_qrcode_QrGenerator_QrGenerate(JNIEnv *env, jobject clazz, jstring text, jstring color, jstring background, jint type, jint correction_level) {
    char const *textString = env->GetStringUTFChars(text, nullptr);
    char const *colorString = env->GetStringUTFChars(color, nullptr);
    char const *backgroundString = env->GetStringUTFChars(background, nullptr);
    QrCode::Ecc errCorLvl;  // Error correction level
    QrCode::Type type_v;
    switch (correction_level) {
        case 0:
            errCorLvl = QrCode::Ecc::LOW;
            break;
        case 1:
            errCorLvl = QrCode::Ecc::MEDIUM;
            break;
        case 2:
            errCorLvl = QrCode::Ecc::QUARTILE;
            break;
        default:
            errCorLvl = QrCode::Ecc::HIGH;
            break;
    }

    switch (type) {
        case 0:
            type_v = QrCode::Type::CIRCLE;
            break;
        case 2:
            type_v = QrCode::Type::SQUARE;
            break;
        default:
            type_v = QrCode::Type::ROUND;
            break;
    }
	
	// Make and print the QR Code symbol
	const QrCode qr = QrCode::encodeText(textString, errCorLvl);
    std::string ret = "null";
    try {
        ret = qr.toSvgString(4, type_v, colorString, backgroundString, false);
    } catch(...) {
        if(textString != nullptr) {
            env->ReleaseStringUTFChars(text, textString);
        }
        if(colorString != nullptr) {
            env->ReleaseStringUTFChars(color, colorString);
        }
        if(backgroundString != nullptr) {
            env->ReleaseStringUTFChars(background, backgroundString);
        }
        return nullptr;
    }
    if(textString != nullptr) {
        env->ReleaseStringUTFChars(text, textString);
    }
    if(colorString != nullptr) {
        env->ReleaseStringUTFChars(color, colorString);
    }
    if(backgroundString != nullptr) {
        env->ReleaseStringUTFChars(background, backgroundString);
    }
    return env->NewStringUTF(ret.data());
}