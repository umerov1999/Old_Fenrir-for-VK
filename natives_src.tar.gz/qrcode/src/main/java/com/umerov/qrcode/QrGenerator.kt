package com.umerov.qrcode

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import com.caverock.androidsvg.SVG
import com.caverock.androidsvg.SVGParseException


object QrGenerator {
    private external fun QrGenerate(text: String, color: String, background: String, type: Int, correction_level: Int): String?

    @JvmStatic
    fun generateQR(context: Context, text: String, color: Int, background: Int, type: Int, correction_level: Int, res: Int): Bitmap? {
        val strColor = String.format("#%06X", 0xFFFFFF and color)
        val backColor = String.format("#%06X", 0xFFFFFF and background)
        val qr = QrGenerate(text, strColor, backColor, type, correction_level) ?: return null
        try {
            val svg = SVG.getFromInputStream(qr.byteInputStream(Charsets.UTF_8))
            val drv = context.resources.getDrawable(res, context.theme)
            val bitmap = Bitmap.createBitmap(500, 500, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(bitmap)
            svg.renderToCanvas(canvas)
            drv.setBounds(200, 200, 300, 300)
            drv.alpha = 200
            drv.draw(canvas)
            return bitmap
        } catch (e: SVGParseException) {
            e.printStackTrace()
        }
        return null
    }

    init {
        System.loadLibrary("qr_generator_jni")
    }
}