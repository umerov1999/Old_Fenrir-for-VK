package dev.ragnarok.fenrir.module.rlottie;

import android.graphics.Bitmap;
import android.graphics.Color;

import androidx.annotation.NonNull;
import androidx.annotation.Px;

import java.io.File;

import dev.ragnarok.fenrir.module.FenrirNative;

public class RLottie2Gif {
    private static DispatchQueuePool runnableQueue;
    private final Builder builder;
    private boolean running;
    private boolean successful;
    private int mFrame, mTotalFrame;
    private final Lottie2GifListener listener = new Lottie2GifListener() {
        @Override
        public void onStarted() {
            running = true;
            if (builder.listener != null) builder.listener.onStarted();
        }

        @Override
        public void onProgress(int frame, int totalFrame) {
            mFrame = frame;
            mTotalFrame = totalFrame;
            if (builder.listener != null) builder.listener.onProgress(frame, totalFrame);
        }

        @Override
        public void onFinished() {
            running = false;

            if (builder.listener != null) builder.listener.onFinished();
        }
    };
    private Bitmap bitmap;
    Runnable converter = new Runnable() {
        @Override
        public void run() {
            if (bitmap == null) {
                try {
                    bitmap = Bitmap.createBitmap(builder.w, builder.h, Bitmap.Config.ARGB_8888);
                } catch (Throwable e) {
                    e.printStackTrace();
                }
            }

            if (bitmap != null) {
                successful = RLottieDrawable.lottie2gif(builder.lottie, bitmap, builder.w, builder.h, bitmap.getRowBytes(),
                        builder.bgColor, builder.bgColor == Color.TRANSPARENT, builder.path.getAbsolutePath(),
                        builder.bitDepth, builder.dither, listener);
            } else {
                successful = false;
            }
        }
    };

    RLottie2Gif(Builder builder) {
        if (runnableQueue == null) runnableQueue = new DispatchQueuePool(2);
        this.builder = builder;
        build();
    }

    public static Builder create(@NonNull RLottieDrawable lottie) {
        return new Builder(lottie);
    }

    public static Builder create(long lottie) {
        return new Builder(lottie);
    }

    public boolean buildAgain() {
        if (isRunning()) return false;
        build();
        return successful;
    }

    private void build() {
        if (builder.async) {
            runnableQueue.execute(converter);
        } else {
            converter.run();
        }
    }

    public boolean isRunning() {
        return running;
    }

    public boolean isSuccessful() {
        return successful;
    }

    public Builder getBuilder() {
        return builder;
    }

    public int getCurrentFrame() {
        return mFrame;
    }

    public int getTotalFrame() {
        return mTotalFrame;
    }

    public File getGifPath() {
        return builder.path;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof RLottie2Gif)) return false;
        RLottie2Gif c = (RLottie2Gif) o;
        if (c.getBuilder() == null) return false;
        return (c.getGifPath().equals(getGifPath()) && c.getBuilder().lottie == builder.lottie);
    }

    @NonNull
    @Override
    public String toString() {
        return getGifPath().getAbsolutePath();
    }

    public interface Lottie2GifListener {
        void onStarted();

        void onProgress(int frame, int totalFrame);

        void onFinished();
    }

    public static class Builder {
        long lottie;
        int w, h;
        int bgColor = Color.WHITE;
        Lottie2GifListener listener;
        File path;
        boolean async = true;
        int bitDepth = 8;
        boolean dither;
        boolean cancelable;

        public Builder(@NonNull RLottieDrawable animation) {
            lottie = animation.getNativePtr();
            float density = FenrirNative.getAppContext().getResources().getDisplayMetrics().density;
            setSize((int) (animation.getMinimumWidth() / density), (int) (animation.getMinimumHeight() / density));
        }

        public Builder(long ptr) {
            lottie = ptr;
            setSize(200, 200);
        }

        public Builder setLottieAnimation(@NonNull RLottieDrawable animation) {
            lottie = animation.getNativePtr();
            return this;
        }

        public Builder setLottieAnimation(long ptr) {
            lottie = ptr;
            return this;
        }

        /**
         * set the output gif background color
         */
        public Builder setBackgroundColor(int bgColor) {
            this.bgColor = bgColor;
            return this;
        }

        /**
         * set the output gif width and height
         */
        public Builder setSize(@Px int width, @Px int height) {
            w = width;
            h = height;
            return this;
        }

        public Builder setListener(Lottie2GifListener listener) {
            this.listener = listener;
            return this;
        }

        /**
         * set the output gif path
         */
        public Builder setOutputPath(@NonNull File gif) {
            path = gif;
            return this;
        }

        /**
         * set the output gif path
         */
        public Builder setOutputPath(@NonNull String gif) {
            path = new File(gif);
            return this;
        }

        public Builder setBackgroundTask(boolean enabled) {
            async = enabled;
            return this;
        }

        /**
         * Implements Floyd-Steinberg dithering, writes palette value to alpha
         */
        public Builder setDithering(boolean enabled) {
            dither = enabled;
            return this;
        }

        public Builder setBitDepth(int bit) {
            bitDepth = bit;
            return this;
        }

        public Builder setCancelable(boolean cancelable) {
            this.cancelable = cancelable;
            return this;
        }

        public RLottie2Gif build() {
            if (path == null) {
                throw new RuntimeException("output gif path can't be null!");
            }
            if (w <= 0 || h <= 0) {
                throw new RuntimeException("output gif width and height must be > 0");
            }

            return new RLottie2Gif(this);
        }
    }

}
