package dev.ragnarok.fenrir.module.hls;

import dev.ragnarok.fenrir.module.FenrirNative;

public class TSDemuxer {
    private static native boolean unpack(String input, String output, boolean info, boolean print_debug);

    public static boolean unpackTS(String input, String output, boolean info, boolean print_debug) {
        if (!FenrirNative.isNativeLoaded()) {
            return false;
        }
        return unpack(input, output, info, print_debug);
    }
}