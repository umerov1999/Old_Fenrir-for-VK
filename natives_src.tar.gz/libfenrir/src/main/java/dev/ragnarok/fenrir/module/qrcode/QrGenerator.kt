package dev.ragnarok.fenrir.module.qrcode

import android.graphics.Bitmap
import android.graphics.Canvas
import com.caverock.androidsvg.SVG
import com.caverock.androidsvg.SVGParseException


object QrGenerator {
    private external fun QrGenerate(
        text: String, logoFirstColor: String,
        logoSecondColor: String, background: String,
        foreground: String, correction_level: Int
    ): String?

    @JvmStatic
    fun generateQR(
        text: String,
        logoFirstColor: Int,
        logoSecondColor: Int,
        background: Int,
        foreground: Int,
        correction_level: Int
    ): Bitmap? {
        val strFirstColor = String.format("#%06X", 0xFFFFFF and logoFirstColor)
        val strSecondColor = String.format("#%06X", 0xFFFFFF and logoSecondColor)
        val backColor = String.format("#%06X", 0xFFFFFF and background)
        val foreColor = String.format("#%06X", 0xFFFFFF and foreground)
        val qr =
            QrGenerate(text, strFirstColor, strSecondColor, backColor, foreColor, correction_level)
                ?: return null
        try {
            val svg = SVG.getFromInputStream(qr.byteInputStream(Charsets.UTF_8))
            val bitmap = Bitmap.createBitmap(512, 512, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(bitmap)
            svg.renderToCanvas(canvas)
            return bitmap
        } catch (e: SVGParseException) {
            e.printStackTrace()
        }
        return null
    }
}