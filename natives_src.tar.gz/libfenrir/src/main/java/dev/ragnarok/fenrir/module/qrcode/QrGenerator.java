package dev.ragnarok.fenrir.module.qrcode;

import android.graphics.Bitmap;
import android.graphics.Canvas;

import com.caverock.androidsvg.SVG;
import com.caverock.androidsvg.SVGParseException;

import javax.annotation.Nullable;

public class QrGenerator {
    private static native @Nullable
    String genQR(String text, String logoFirstColor, String logoSecondColor, String background, String foreground, int correction_level);

    public static @Nullable
    Bitmap generateQR(String text, int logoFirstColor, int logoSecondColor, int background, int foreground, int correction_level) {
        String strFirstColor = String.format("#%06X", 0xFFFFFF & logoFirstColor);
        String strSecondColor = String.format("#%06X", 0xFFFFFF & logoSecondColor);
        String backColor = String.format("#%06X", 0xFFFFFF & background);
        String foreColor = String.format("#%06X", 0xFFFFFF & foreground);
        String qr = genQR(text, strFirstColor, strSecondColor, backColor, foreColor, correction_level);
        if (qr == null || qr.isEmpty()) {
            return null;
        }
        try {
            SVG svg = SVG.getFromString(qr);
            Bitmap bitmap = Bitmap.createBitmap(512, 512, Bitmap.Config.ARGB_8888);
            Canvas canvas = new Canvas(bitmap);
            svg.renderToCanvas(canvas);
            return bitmap;
        } catch (SVGParseException e) {
            e.printStackTrace();
        }
        return null;
    }
}