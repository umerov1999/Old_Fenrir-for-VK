package dev.ragnarok.fenrir.module.qrcode;

import androidx.annotation.ColorInt;
import androidx.annotation.NonNull;

import javax.annotation.Nullable;

public class QrGenerator {
    private static native @Nullable
    String genQR(String text, String logoFirstColor, String logoSecondColor, String background, String foreground, int correction_level);

    public static @Nullable
    String generateQR(@NonNull String text, @ColorInt int logoFirstColor, @ColorInt int logoSecondColor, @ColorInt int background, @ColorInt int foreground, int correction_level) {
        String strFirstColor = String.format("#%06X", 0xFFFFFF & logoFirstColor);
        String strSecondColor = String.format("#%06X", 0xFFFFFF & logoSecondColor);
        String backColor = String.format("#%06X", 0xFFFFFF & background);
        String foreColor = String.format("#%06X", 0xFFFFFF & foreground);
        return genQR(text, strFirstColor, strSecondColor, backColor, foreColor, correction_level);
    }
}