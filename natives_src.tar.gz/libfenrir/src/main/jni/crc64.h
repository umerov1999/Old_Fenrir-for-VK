#ifndef crc64_h
#define crc64_h

#include <unistd.h>
#include <iostream>

void crc64(uint64_t &crc, const void *s, int l);

std::string dumpCrc64(uint64_t crc);

#endif