#ifndef CONFIG_H
#define CONFIG_H

//enable logging
//#define LOTTIE_LOGGING_SUPPORT

//#define LOTTIE_THREAD_SUPPORT

#define LOTTIE_THREAD_SAFE

#endif  // CONFIG_H
