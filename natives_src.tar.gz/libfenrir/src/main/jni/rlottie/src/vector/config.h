#ifndef CONFIG_H
#define CONFIG_H

//enable logging
//#define LOTTIE_LOGGING_SUPPORT

//enable static building of image loader
#define LOTTIE_STATIC_IMAGE_LOADER

#define LOTTIE_THREAD_SAFE

//#define LOTTIE_THREAD_SUPPORT

#endif  // CONFIG_H
