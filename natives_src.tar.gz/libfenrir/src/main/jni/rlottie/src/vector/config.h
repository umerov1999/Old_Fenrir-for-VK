#ifndef CONFIG_H
#define CONFIG_H

//enable logging
//#define LOTTIE_LOGGING_SUPPORT

//#define LOTTIE_THREAD_SUPPORT

#define LOTTIE_THREAD_SAFE

#define BIG_ENDIAN_COLORS

#endif  // CONFIG_H
