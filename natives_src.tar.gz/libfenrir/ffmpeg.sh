#!/bin/bash
cd ~/
git clone git://source.ffmpeg.org/ffmpeg
cd ffmpeg
git checkout release/4.4
rm -r -f ".git"

ENABLED_DECODERS=(aac mp3 h264 hevc gif ac3 eac3 truehd dca vorbis opus amrnb amrwb flac alac pcm_mulaw pcm_alaw)
HOST_PLATFORM="linux-x86_64"
NDK_PATH="/home/umerov/Android/Sdk/ndk/21.4.7075529"

echo 'Please input platform version (Example 22 - Android 5.1): '
read ANDROID_PLATFORM

cd /home/umerov/Fenrir-for-VK/libfenrir/src/main/jni/
./build_ffmpeg.sh "${NDK_PATH}" "${HOST_PLATFORM}" "${ANDROID_PLATFORM}" "${ENABLED_DECODERS[@]}"
