package dev.ragnarok.fenrir.module;

import android.content.Context;

import androidx.annotation.NonNull;

public class FenrirNative {
    private static volatile boolean nativeLoaded;
    private static volatile Context mAppContext;

    public static synchronized void loadNativeLibrary(@NonNull NativeOnException exceptionControl) {
        if (nativeLoaded) {
            return;
        }
        try {
            System.loadLibrary("fenrir_jni");
            nativeLoaded = true;
        } catch (Error e) {
            exceptionControl.onException(e);
        }
    }

    public static synchronized void updateAppContext(@NonNull Context context) {
        mAppContext = context;
    }

    public interface NativeOnException {
        void onException(Error e);
    }

    @NonNull
    public static synchronized Context getAppContext() {
        return mAppContext;
    }

    public static synchronized boolean isNativeLoaded() {
        return nativeLoaded;
    }
}