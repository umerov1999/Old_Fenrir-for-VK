package dev.ragnarok.fenrir.module.rlottie;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RawRes;

import com.google.android.material.imageview.ShapeableImageView;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Objects;

import dev.ragnarok.fenrir.module.BuildConfig;
import dev.ragnarok.fenrir.module.FenrirNative;
import dev.ragnarok.fenrir.module.R;
import io.reactivex.rxjava3.android.schedulers.AndroidSchedulers;
import io.reactivex.rxjava3.core.Completable;
import io.reactivex.rxjava3.core.CompletableTransformer;
import io.reactivex.rxjava3.disposables.Disposable;
import io.reactivex.rxjava3.functions.Consumer;
import io.reactivex.rxjava3.schedulers.Schedulers;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class RLottieShapeableImageView extends ShapeableImageView {

    private final NetworkCache cache;
    private HashMap<String, Integer> layerColors;
    private RLottieDrawable drawable;
    private boolean autoRepeat;
    private boolean attachedToWindow;
    private boolean playing;
    private Disposable mDisposable = Disposable.disposed();

    public RLottieShapeableImageView(Context context) {
        this(context, null);
    }

    public RLottieShapeableImageView(Context context, AttributeSet attrs) {
        super(context, attrs);
        cache = new NetworkCache(context);

        @SuppressLint("CustomViewStyleable") TypedArray a = context.obtainStyledAttributes(attrs, R.styleable.RLottieImageView);
        int animRes = a.getResourceId(R.styleable.RLottieImageView_fromRes, 0);
        autoRepeat = a.getBoolean(R.styleable.RLottieImageView_loopAnimation, false);
        int width = (int) a.getDimension(R.styleable.RLottieImageView_w, 28);
        int height = (int) a.getDimension(R.styleable.RLottieImageView_h, 28);
        a.recycle();

        if (FenrirNative.isNativeLoaded() && animRes != 0) {
            drawable = new RLottieDrawable(animRes, "" + animRes, width, height, false, null);
            setAnimation(drawable);
            playAnimation();
        }
    }

    private static CompletableTransformer applyCompletableIOToMainSchedulers() {
        return completable -> completable.subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread());
    }

    private static <T> Consumer<T> ignore() {
        return t -> {
            if (t instanceof Throwable && BuildConfig.DEBUG) {
                ((Throwable) t).printStackTrace();
            }
        };
    }

    public void clearLayerColors() {
        layerColors.clear();
    }

    public void setLayerColor(String layer, int color) {
        if (layerColors == null) {
            layerColors = new HashMap<>();
        }
        layerColors.put(layer, color);
        if (drawable != null) {
            drawable.setLayerColor(layer, color);
        }
    }

    public void replaceColors(int[] colors) {
        if (drawable != null) {
            drawable.replaceColors(colors);
        }
    }

    private void setAnimationByUrlCache(String url, int w, int h) {
        if (!FenrirNative.isNativeLoaded()) {
            return;
        }
        File ch = cache.fetch(url);
        if (ch == null) {
            setImageDrawable(null);
            return;
        }
        autoRepeat = false;
        setAnimation(new RLottieDrawable(ch, true, w, h, false, null));
        playAnimation();
    }

    public void fromNet(String url, OkHttpClient.Builder client, int w, int h) {
        if (!FenrirNative.isNativeLoaded() || url == null || url.isEmpty()) {
            return;
        }
        clearAnimationDrawable();
        if (cache.isCachedFile(url)) {
            setAnimationByUrlCache(url, w, h);
            return;
        }
        mDisposable = Completable.create(u -> {
            try {
                Request request = new Request.Builder()
                        .url(url)
                        .build();
                Response response = client.build().newCall(request).execute();
                if (!response.isSuccessful()) {
                    u.onComplete();
                    return;
                }
                InputStream bfr = Objects.requireNonNull(response.body()).byteStream();
                BufferedInputStream input = new BufferedInputStream(bfr);
                cache.writeTempCacheFile(url, input);
                input.close();
                cache.renameTempFile(url);
            } catch (Exception e) {
                u.onComplete();
                return;
            }
            u.onComplete();
        }).compose(applyCompletableIOToMainSchedulers()).subscribe(() -> setAnimationByUrlCache(url, w, h), ignore());
    }

    private void setAnimation(@NonNull RLottieDrawable rLottieDrawable) {
        drawable = rLottieDrawable;
        drawable.setAutoRepeat(autoRepeat ? 1 : 0);
        if (layerColors != null) {
            drawable.beginApplyLayerColors();
            for (HashMap.Entry<String, Integer> entry : layerColors.entrySet()) {
                drawable.setLayerColor(entry.getKey(), entry.getValue());
            }
            drawable.commitApplyLayerColors();
        }
        drawable.setAllowDecodeSingleFrame(true);
        setImageDrawable(drawable);
    }

    public void fromRes(@RawRes int resId, int w, int h) {
        fromRes(resId, w, h, null);
    }

    public void fromRes(@RawRes int resId, int w, int h, int[] colorReplacement) {
        if (!FenrirNative.isNativeLoaded()) {
            return;
        }
        clearAnimationDrawable();
        drawable = new RLottieDrawable(resId, "" + resId, w, h, false, colorReplacement);
        setAnimation(drawable);
    }

    public void fromFile(@NonNull File file, int w, int h) {
        fromFile(file, w, h, null);
    }

    public void fromFile(@NonNull File file, int w, int h, int[] colorReplacement) {
        if (!FenrirNative.isNativeLoaded()) {
            return;
        }
        clearAnimationDrawable();
        drawable = new RLottieDrawable(file, false, w, h, false, colorReplacement);
        setAnimation(drawable);
    }

    public void clearAnimationDrawable() {
        if (drawable != null) {
            drawable.stop();
        }
        drawable = null;
        setImageDrawable(null);
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        attachedToWindow = true;
        if (drawable != null) {
            drawable.setCallback(this);
            if (playing) {
                drawable.start();
            }
        }
    }

    @Override
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        attachedToWindow = false;
        if (drawable != null) {
            drawable.stop();
        }
        mDisposable.dispose();
    }

    public boolean isPlaying() {
        return drawable != null && drawable.isRunning();
    }

    public void setAutoRepeat(boolean repeat) {
        autoRepeat = repeat;
    }

    public void setProgress(float progress) {
        if (drawable == null) {
            return;
        }
        drawable.setProgress(progress);
    }

    @Override
    public void setImageDrawable(@Nullable Drawable dr) {
        super.setImageDrawable(dr);
        if (!(dr instanceof RLottieDrawable)) {
            if (drawable != null) {
                drawable.stop();
            }
            drawable = null;
        }
    }

    @Override
    public void setImageBitmap(@Nullable Bitmap bm) {
        super.setImageBitmap(bm);
        if (drawable != null) {
            drawable.stop();
        }
        drawable = null;
    }

    @Override
    public void setImageResource(int resId) {
        super.setImageResource(resId);
        if (drawable != null) {
            drawable.stop();
        }
        drawable = null;
    }

    public void playAnimation() {
        if (drawable == null) {
            return;
        }
        playing = true;
        if (attachedToWindow) {
            drawable.start();
        }
    }

    public void replayAnimation() {
        if (drawable == null) {
            return;
        }
        playing = true;
        if (attachedToWindow) {
            drawable.stop();
            drawable.setAutoRepeat(1);
            drawable.start();
        }
    }

    public void resetFrame() {
        if (drawable == null) {
            return;
        }
        playing = true;
        if (attachedToWindow) {
            drawable.setAutoRepeat(1);
        }
    }

    public void stopAnimation() {
        if (drawable == null) {
            return;
        }
        playing = false;
        if (attachedToWindow) {
            drawable.stop();
        }
    }

    public @Nullable
    RLottieDrawable getAnimatedDrawable() {
        return drawable;
    }
}
