package dev.libfenrir.parcel;

import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class ParcelNative {
    private long nativePointer;

    private final UpdatePointerListener updateListener = this::updateNative;

    private static native long init();

    private static native void putBoolean(long parcel, boolean value);

    private static native void putByte(long parcel, byte value);

    private static native void putInt(long parcel, int value);

    private static native void putLong(long parcel, long value);

    private static native void putFloat(long parcel, float value);

    private static native void putDouble(long parcel, double value);

    private static native void putString(long parcel, String value);

    private static native boolean readBoolean(long parcel, UpdatePointerListener listener);

    private static native byte readByte(long parcel, UpdatePointerListener listener);

    private static native int readInt(long parcel, UpdatePointerListener listener);

    private static native long readLong(long parcel, UpdatePointerListener listener);

    private static native float readFloat(long parcel, UpdatePointerListener listener);

    private static native double readDouble(long parcel, UpdatePointerListener listener);

    private static native String readString(long parcel, UpdatePointerListener listener);

    public static <T extends ParcelableNative> long createParcelableList(Collection<T> data) {
        ParcelNative ret = create();
        ret.writeParcelableList(data);
        return ret.nativePointer;
    }

    public static <T extends ParcelableNative> List<T> loadParcelableList(long pointer, Creator<T> loader) {
        ParcelNative ret = fromNative(pointer);
        return ret.readParcelableList(loader);
    }

    public static <T extends ParcelableNative> ArrayList<T> loadParcelableArrayList(long pointer, Creator<T> loader) {
        ParcelNative ret = fromNative(pointer);
        return ret.readParcelableArrayList(loader);
    }

    public static ParcelNative fromNative(long value) {
        ParcelNative ret = new ParcelNative();
        ret.updateNative(value);
        return ret;
    }

    public static ParcelNative create() {
        ParcelNative ret = new ParcelNative();
        ret.updateNative(init());
        return ret;
    }

    private void updateNative(long value) {
        nativePointer = value;
    }

    public long getNativePointer() {
        return nativePointer;
    }

    public ParcelNative writeString(@Nullable String value) {
        if (value == null) {
            putBoolean(nativePointer, false);
        } else {
            putBoolean(nativePointer, true);
            putString(nativePointer, value);
        }
        return this;
    }

    public ParcelNative writeBoolean(boolean value) {
        putBoolean(nativePointer, value);
        return this;
    }

    public ParcelNative writeByte(byte value) {
        putByte(nativePointer, value);
        return this;
    }

    public ParcelNative writeInt(int value) {
        putInt(nativePointer, value);
        return this;
    }

    public ParcelNative writeLong(long value) {
        putLong(nativePointer, value);
        return this;
    }

    public ParcelNative writeFloat(float value) {
        putFloat(nativePointer, value);
        return this;
    }

    public ParcelNative writeDouble(double value) {
        putDouble(nativePointer, value);
        return this;
    }

    public ParcelNative writeStringList(Collection<String> data) {
        if (data == null) {
            putInt(nativePointer, 0);
            return this;
        }
        putInt(nativePointer, data.size());
        for (String i : data) {
            putString(nativePointer, i);
        }
        return this;
    }

    public ParcelNative writeIntegerList(Collection<Integer> data) {
        if (data == null) {
            putInt(nativePointer, 0);
            return this;
        }
        putInt(nativePointer, data.size());
        for (Integer i : data) {
            putInt(nativePointer, i);
        }
        return this;
    }

    public ParcelNative writeLongList(Collection<Long> data) {
        if (data == null) {
            putInt(nativePointer, 0);
            return this;
        }
        putInt(nativePointer, data.size());
        for (Long i : data) {
            putLong(nativePointer, i);
        }
        return this;
    }

    public ParcelNative writeFloatList(Collection<Float> data) {
        if (data == null) {
            putInt(nativePointer, 0);
            return this;
        }
        putInt(nativePointer, data.size());
        for (Float i : data) {
            putFloat(nativePointer, i);
        }
        return this;
    }

    public ParcelNative writeDoubleList(Collection<Double> data) {
        if (data == null) {
            putInt(nativePointer, 0);
            return this;
        }
        putInt(nativePointer, data.size());
        for (Double i : data) {
            putDouble(nativePointer, i);
        }
        return this;
    }

    public List<String> readStringList() {
        int size = readInt(nativePointer, updateListener);
        List<String> ret = new ArrayList<>(size);
        for (int i = 0; i < size; i++) {
            ret.add(readString(nativePointer, updateListener));
        }
        return ret;
    }

    public List<Integer> readIntegerList() {
        int size = readInt(nativePointer, updateListener);
        List<Integer> ret = new ArrayList<>(size);
        for (int i = 0; i < size; i++) {
            ret.add(readInt(nativePointer, updateListener));
        }
        return ret;
    }

    public List<Long> readLongList() {
        int size = readInt(nativePointer, updateListener);
        List<Long> ret = new ArrayList<>(size);
        for (int i = 0; i < size; i++) {
            ret.add(readLong(nativePointer, updateListener));
        }
        return ret;
    }

    public List<Float> readFloatList() {
        int size = readInt(nativePointer, updateListener);
        List<Float> ret = new ArrayList<>(size);
        for (int i = 0; i < size; i++) {
            ret.add(readFloat(nativePointer, updateListener));
        }
        return ret;
    }

    public List<Double> readDoubleList() {
        int size = readInt(nativePointer, updateListener);
        List<Double> ret = new ArrayList<>(size);
        for (int i = 0; i < size; i++) {
            ret.add(readDouble(nativePointer, updateListener));
        }
        return ret;
    }

    public @Nullable
    String readString() {
        if (!readBoolean(nativePointer, updateListener)) {
            return null;
        }
        return readString(nativePointer, updateListener);
    }

    public boolean readBoolean() {
        return readBoolean(nativePointer, updateListener);
    }

    public byte readByte() {
        return readByte(nativePointer, updateListener);
    }

    public int readInt() {
        return readInt(nativePointer, updateListener);
    }

    public long readLong() {
        return readLong(nativePointer, updateListener);
    }

    public float readFloat() {
        return readFloat(nativePointer, updateListener);
    }

    public double readDouble() {
        return readDouble(nativePointer, updateListener);
    }

    public <T extends ParcelableNative> T readParcelable(Creator<T> loader) {
        boolean isNotNull = readBoolean();
        if (!isNotNull) {
            return null;
        }
        return loader.readFromParcelNative(this);
    }

    public <T extends ParcelableNative> void writeParcelable(@Nullable T parcelable) {
        writeBoolean(parcelable != null);
        if (parcelable != null) {
            parcelable.writeToParcelNative(this);
        }
    }

    public <T extends ParcelableNative> List<T> readParcelableList(Creator<T> loader) {
        int size = readInt(nativePointer, updateListener);
        List<T> ret = new ArrayList<>(size);
        for (int i = 0; i < size; i++) {
            ret.add(readParcelable(loader));
        }
        return ret;
    }

    public <T extends ParcelableNative> ArrayList<T> readParcelableArrayList(Creator<T> loader) {
        int size = readInt(nativePointer, updateListener);
        ArrayList<T> ret = new ArrayList<>(size);
        for (int i = 0; i < size; i++) {
            ret.add(readParcelable(loader));
        }
        return ret;
    }

    public <T extends ParcelableNative> ParcelNative writeParcelableList(Collection<T> data) {
        if (data == null) {
            putInt(nativePointer, 0);
            return this;
        }
        putInt(nativePointer, data.size());
        for (T i : data) {
            writeParcelable(i);
        }
        return this;
    }

    public interface UpdatePointerListener {
        void doUpdateNative(long pointer);
    }

    public interface ParcelableNative {
        void writeToParcelNative(ParcelNative dest);
    }

    public interface Creator<T extends ParcelableNative> {
        T readFromParcelNative(ParcelNative dest);
    }
}
