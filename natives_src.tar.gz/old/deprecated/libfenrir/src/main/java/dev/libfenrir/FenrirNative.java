package dev.libfenrir;

import android.content.Context;

import androidx.annotation.NonNull;

public class FenrirNative {
    private static volatile boolean nativeLoaded;
    private static volatile Context mAppContext;

    public static synchronized void loadNativeLibrary() {
        if (nativeLoaded) {
            return;
        }
        try {
            System.loadLibrary("fenrir_jni");
            nativeLoaded = true;
        } catch (Error e) {
            e.printStackTrace();
        }
    }

    public static synchronized void updateAppContext(@NonNull Context context) {
        mAppContext = context;
    }

    @NonNull
    public static synchronized Context getAppContext() {
        return mAppContext;
    }

    public static synchronized boolean isNativeLoaded() {
        return nativeLoaded;
    }
}