#include <jni.h>
#include <android/bitmap.h>
#include <cstring>
#include <rlottie.h>
#include <unistd.h>
#include <condition_variable>
#include <atomic>
#include <thread>
#include <map>
#include <sys/stat.h>
#include <utime.h>
#include "utils.h"
#include "gif.h"

extern "C" {
using namespace rlottie;

class LottieInfo {
public:
    std::unique_ptr<Animation> animation;
    size_t frameCount = 0;
    int32_t fps = 30;
};

JNIEXPORT jlong
Java_dev_ragnarok_fenrir_module_rlottie_RLottieDrawable_create(JNIEnv *env, jclass, jstring src, jintArray data,
                                                  jintArray colorReplacement) {
    auto *info = new LottieInfo();

    std::map<int32_t, int32_t> *colors = nullptr;
    int color = 0;
    if (colorReplacement != nullptr) {
        jint *arr = env->GetIntArrayElements(colorReplacement, nullptr);
        if (arr != nullptr) {
            jsize len = env->GetArrayLength(colorReplacement);
            colors = new std::map<int32_t, int32_t>();
            for (int32_t a = 0; a < len / 2; a++) {
                (*colors)[arr[a * 2]] = arr[a * 2 + 1];
                if (color == 0) {
                    color = arr[a * 2 + 1];
                }
            }
            env->ReleaseIntArrayElements(colorReplacement, arr, 0);
        }
    }

    char const *srcString = env->GetStringUTFChars(src, nullptr);
    info->animation = rlottie::Animation::loadFromFile(srcString, colors);
    if (srcString != nullptr) {
        env->ReleaseStringUTFChars(src, srcString);
    }
    if (info->animation == nullptr) {
        delete info;
        return 0;
    }
    info->frameCount = info->animation->totalFrame();
    info->fps = (int) info->animation->frameRate();
    if (info->fps > 60 || info->frameCount > 600) {
        //delete info;
        //return 0;
    }

    jint *dataArr = env->GetIntArrayElements(data, nullptr);
    if (dataArr != nullptr) {
        dataArr[0] = (jint) info->frameCount;
        dataArr[1] = (jint) info->animation->frameRate();
        env->ReleaseIntArrayElements(data, dataArr, 0);
    }
    return (jlong) (intptr_t) info;
}

JNIEXPORT jlong
Java_dev_ragnarok_fenrir_module_rlottie_RLottieDrawable_createWithJson(JNIEnv *env, jclass, jstring json,
                                                          jstring name, jintArray data,
                                                          jintArray colorReplacement) {
    std::map<int32_t, int32_t> *colors = nullptr;
    if (colorReplacement != nullptr) {
        jint *arr = env->GetIntArrayElements(colorReplacement, nullptr);
        if (arr != nullptr) {
            jsize len = env->GetArrayLength(colorReplacement);
            colors = new std::map<int32_t, int32_t>();
            for (int32_t a = 0; a < len / 2; a++) {
                (*colors)[arr[a * 2]] = arr[a * 2 + 1];
            }
            env->ReleaseIntArrayElements(colorReplacement, arr, 0);
        }
    }

    auto *info = new LottieInfo();

    char const *jsonString = env->GetStringUTFChars(json, nullptr);
    char const *nameString = env->GetStringUTFChars(name, nullptr);
    info->animation = rlottie::Animation::loadFromData(jsonString, nameString, colors);
    if (jsonString != nullptr) {
        env->ReleaseStringUTFChars(json, jsonString);
    }
    if (nameString != nullptr) {
        env->ReleaseStringUTFChars(name, nameString);
    }
    if (info->animation == nullptr) {
        delete info;
        return 0;
    }
    info->frameCount = info->animation->totalFrame();
    info->fps = (int) info->animation->frameRate();

    jint *dataArr = env->GetIntArrayElements(data, nullptr);
    if (dataArr != nullptr) {
        dataArr[0] = (int) info->frameCount;
        dataArr[1] = (int) info->animation->frameRate();
        env->ReleaseIntArrayElements(data, dataArr, 0);
    }
    return (jlong) (intptr_t) info;
}

JNIEXPORT void
Java_dev_ragnarok_fenrir_module_rlottie_RLottieDrawable_destroy(JNIEnv *, jclass, jlong ptr) {
    if (!ptr) {
        return;
    }
    auto *info = (LottieInfo *) (intptr_t) ptr;
    delete info;
}

JNIEXPORT void
Java_dev_ragnarok_fenrir_module_rlottie_RLottieDrawable_setLayerColor(JNIEnv *env, jclass, jlong ptr,
                                                         jstring layer, jint color) {
    if (!ptr || layer == nullptr) {
        return;
    }
    auto *info = (LottieInfo *) (intptr_t) ptr;
    char const *layerString = env->GetStringUTFChars(layer, nullptr);
    info->animation->setValue<Property::Color>(layerString, Color(((color) & 0xff) / 255.0f,
                                                                  ((color >> 8) & 0xff) / 255.0f,
                                                                  ((color >> 16) & 0xff) / 255.0f));
    if (layerString != nullptr) {
        env->ReleaseStringUTFChars(layer, layerString);
    }
}

JNIEXPORT void
Java_dev_ragnarok_fenrir_module_rlottie_RLottieDrawable_replaceColors(JNIEnv *env, jclass, jlong ptr,
                                                         jintArray colorReplacement) {
    if (!ptr || colorReplacement == nullptr) {
        return;
    }
    auto *info = (LottieInfo *) (intptr_t) ptr;
    if (!info->animation->colorMap) {
        return;
    }
    jint *arr = env->GetIntArrayElements(colorReplacement, nullptr);
    if (arr != nullptr) {
        jsize len = env->GetArrayLength(colorReplacement);
        for (int32_t a = 0; a < len / 2; a++) {
            (*info->animation->colorMap)[arr[a * 2]] = arr[a * 2 + 1];
        }
        info->animation->resetCurrentFrame();
        env->ReleaseIntArrayElements(colorReplacement, arr, 0);
    }
}

JNIEXPORT jint
Java_dev_ragnarok_fenrir_module_rlottie_RLottieDrawable_getFrame(JNIEnv *env, jclass, jlong ptr,
                                                    jint frame,
                                                    jobject bitmap, jint w, jint h, jint stride,
                                                    jboolean clear) {
    if (!ptr || bitmap == nullptr) {
        return 0;
    }
    auto *info = (LottieInfo *) (intptr_t) ptr;

    void *pixels;
    if (AndroidBitmap_lockPixels(env, bitmap, &pixels) >= 0) {
        Surface surface((uint32_t *) pixels, (size_t) w, (size_t) h, (size_t) stride);
        info->animation->renderSync((size_t) frame, surface, clear);

        AndroidBitmap_unlockPixels(env, bitmap);
    }
    return frame;
}

class Lottie2Gif {
public:
    static bool render(LottieInfo *player, jobject bitmap, int w, int h, int stride, int bgColor,
                       bool transparent, const std::string &gifName, int bitDepth,
                       bool dither, JNIEnv *env, jobject listener) {
        void *pixels;
        if (AndroidBitmap_lockPixels(env, bitmap, &pixels) >= 0) {
            size_t frameCount = player->animation->totalFrame();
            //auto pixels = std::unique_ptr<uint32_t[]>(new uint32_t[w * h]);

            uint32_t delay = 2;
            GifBuilder builder(gifName, w, h, bgColor, delay, bitDepth, dither);
            size_t start = 0, end = frameCount;

            if (listener != nullptr) {
                jweak store_Wlistener = env->NewWeakGlobalRef(listener);
                jclass clazz = env->GetObjectClass(store_Wlistener);

                jmethodID mth_update = env->GetMethodID(clazz, "onProgress", "(II)V");
                jmethodID mth_start = env->GetMethodID(clazz, "onStarted", "()V");
                jmethodID mth_end = env->GetMethodID(clazz, "onFinished", "()V");

                env->CallVoidMethod(store_Wlistener, mth_start);

                for (size_t i = start; i < end; i++) {
                    rlottie::Surface surface((uint32_t *) pixels, (size_t) w, (size_t) h,
                                             (size_t) stride);
                    player->animation->renderSync(i, surface, true);
                    builder.addFrame(surface, transparent, delay, bitDepth, dither);

                    env->CallVoidMethod(store_Wlistener, mth_update, (jint) (i + 1),
                                        (jint) frameCount);
                }

                env->CallVoidMethod(store_Wlistener, mth_end);
            } else {
                for (size_t i = start; i < end; i++) {
                    rlottie::Surface surface((uint32_t *) pixels, (size_t) w, (size_t) h,
                                             (size_t) stride);
                    player->animation->renderSync(i, surface, true);
                    builder.addFrame(surface, transparent, delay, bitDepth, dither);
                }
            }

            AndroidBitmap_unlockPixels(env, bitmap);
            return true;
        }
        return false;
    }

};

JNIEXPORT
jboolean Java_dev_ragnarok_fenrir_module_rlottie_RLottieDrawable_lottie2gif(JNIEnv *env, jclass, jlong ptr,
                                                               jobject bitmap, jint w, jint h,
                                                               jint stride, jint bgColor,
                                                               jboolean transparent,
                                                               jstring gifName,
                                                               jint bitDepth,
                                                               jboolean dither, jobject listener) {
    if (!ptr) {
        return false;
    }
    char const *name = env->GetStringUTFChars(gifName, nullptr);
    auto *info = (LottieInfo *) (intptr_t) ptr;
    return Lottie2Gif::render(info, bitmap, w, h, stride, bgColor, (bool) transparent, name,
                              bitDepth, dither, env, listener);
}

}
