#include <jni.h>
#include <cstdint>
#include <cstdlib>
#include <cstring>
#include <iostream>
#include <string>
#include <vector>
#include "qr_code.h"

using std::uint8_t;

extern "C" JNIEXPORT jstring
Java_dev_libfenrir_qrcode_QrGenerator_QrGenerate(JNIEnv *env, jobject, jstring text,
                                                 jstring logoFirstColor, jstring logoSecondColor,
                                                 jstring background, jstring foreground,
                                                 jint correction_level) {
    char const *textString = env->GetStringUTFChars(text, nullptr);
    char const *logoFirstColorString = env->GetStringUTFChars(logoFirstColor, nullptr);
    char const *logoSecondColorString = env->GetStringUTFChars(logoSecondColor, nullptr);
    char const *backgroundString = env->GetStringUTFChars(background, nullptr);
    char const *foregroundString = env->GetStringUTFChars(foreground, nullptr);
    QrCode::Ecc errCorLvl;  // Error correction level
    switch (correction_level) {
        case 0:
            errCorLvl = QrCode::Ecc::LOW;
            break;
        case 1:
            errCorLvl = QrCode::Ecc::MEDIUM;
            break;
        case 2:
            errCorLvl = QrCode::Ecc::QUARTILE;
            break;
        default:
            errCorLvl = QrCode::Ecc::HIGH;
            break;
    }

    // Make and print the QR Code symbol
    const QrCode qr = QrCode::encodeText(textString, errCorLvl);
    std::string ret = "null";
    try {
        QrCode::QROptions options;
        options.qrSize = 512;
        options.backgroundColor = backgroundString;
        options.foregroundColor = foregroundString;
        options.isShowBackground = true;
        options.isShowLogo = true;
        options.logoFirstColor = logoFirstColorString;
        options.logoSecondColor = logoSecondColorString;
        options.suffix = "ragnarok";
        ret = qr.convertSegmentsToSvgString(options);
    } catch (...) {
        if (textString != nullptr) {
            env->ReleaseStringUTFChars(text, textString);
        }
        if (logoFirstColorString != nullptr) {
            env->ReleaseStringUTFChars(logoFirstColor, logoFirstColorString);
        }
        if (logoSecondColorString != nullptr) {
            env->ReleaseStringUTFChars(logoSecondColor, logoSecondColorString);
        }
        if (backgroundString != nullptr) {
            env->ReleaseStringUTFChars(background, backgroundString);
        }
        if (foregroundString != nullptr) {
            env->ReleaseStringUTFChars(foreground, foregroundString);
        }
        return nullptr;
    }
    if (textString != nullptr) {
        env->ReleaseStringUTFChars(text, textString);
    }
    if (logoFirstColorString != nullptr) {
        env->ReleaseStringUTFChars(logoFirstColor, logoFirstColorString);
    }
    if (logoSecondColorString != nullptr) {
        env->ReleaseStringUTFChars(logoSecondColor, logoSecondColorString);
    }
    if (backgroundString != nullptr) {
        env->ReleaseStringUTFChars(background, backgroundString);
    }
    if (foregroundString != nullptr) {
        env->ReleaseStringUTFChars(foreground, foregroundString);
    }
    return env->NewStringUTF(ret.data());
}
